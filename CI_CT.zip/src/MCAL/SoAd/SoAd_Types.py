from dataclasses import dataclass

@dataclass
class SoAd_PduType:
    soAd_Data: bytes
