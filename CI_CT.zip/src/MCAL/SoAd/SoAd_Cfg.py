# Placeholder config
SOAD_CHANNEL_ID_DIAG = 1
