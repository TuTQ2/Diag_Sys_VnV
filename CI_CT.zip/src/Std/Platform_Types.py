# Simplified AUTOSAR-like platform types (Python doesn't need much here)
uint8 = int
uint16 = int
uint32 = int
sint8 = int
sint16 = int
sint32 = int
float32 = float
